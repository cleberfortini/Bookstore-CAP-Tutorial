## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Sun Mar 29 2026 21:21:33 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>SAP Fiori Application Generator|
|**App Generator Version**<br>1.22.0|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>Local CAP|
|**Service URL**<br>http://localhost:4004/odata/v4/bookstore/|
|**Module Name**<br>bookstore-listview|
|**Application Title**<br>Book Store View |
|**Namespace**<br>cviana.com.br|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.146.0|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/@sap-ux/eslint-plugin-fiori-tools#rules for the eslint rules.|
|**Main Entity**<br>Books|
|**Navigation Entity**<br>None|

## bookstore-listview

Book Store

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  To launch the generated app, start your CAP project:  and navigate to the following location in your browser:

http://localhost:4004/bookstore-listview/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


